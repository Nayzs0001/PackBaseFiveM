# Loaf Lib
A work in progress resource that I use for some of my scripts. It handles stuff like markers, keybindings, 3d text, callbacks and more. Make sure to check out the config!

## Resource friendly
The resource uses 0.00ms idle without any markers. With 300+ markers it uses ~0.02ms when drawing 2 markers.

## Usage for developers
Guide coming soon. For now, look a the files & the wiki.