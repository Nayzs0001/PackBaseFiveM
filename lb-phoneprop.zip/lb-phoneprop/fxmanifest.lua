fx_version "cerulean"
game "gta5"

author "LB"
title "LB Phone Model"
description "Phone prop for lb-phone"

this_is_a_map "yes"

files {
    "stream/lbphone_props.ytyp"
}

data_file "DLC_ITYP_REQUEST" "lbphone_props.ytyp"

dependency '/assetpacks'