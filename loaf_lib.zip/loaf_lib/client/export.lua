functions = {}

exports("GetLib", function()
    return functions
end)